---
type: contact
name: Ant Sharman
organisation: Evocatus Consulting Ltd
role: Director
email: ant.sharman@evocatus.co.uk
linkedin: https://www.linkedin.com/in/antsharman/
website: https://www.evocatus.co.uk
status: active
tags: [evocatus, wargaming, defence, army-reserve]
---

# Ant Sharman

## Contact Details

- **Organisation:** [[CRM/organisations/defence companies/Evocatus|Evocatus Consulting Ltd]] — Director and Founder
- **Email:** ant.sharman@evocatus.co.uk
- **LinkedIn:** [antsharman](https://www.linkedin.com/in/antsharman/)
- **Bluesky:** [zeroecho.uk](https://bsky.app/profile/zeroecho.uk)
- **Website:** [evocatus.co.uk](https://www.evocatus.co.uk/)
- **Personal site:** [Zero Echo](https://zeroecho.uk/) — Ant's personal journal of working notes.
- **Location:** Dorchester, England

## Background

Ant Sharman is a British Army veteran with expertise in wargaming, exercise design, military training, and facilitation. He served nearly 16 years in the Regular Army with The King's Royal Hussars (Royal Armoured Corps), in roles including Challenger 2 Troop Leader, Squadron Second-in-Command, Battle Group Intelligence Officer, Squadron Leader, and Chief Instructor at the Reconnaissance and Armoured Tactics Division in Warminster. He also served as Collective Training Planner at the British Army Training Unit Suffield (BATUS) in Canada. He saw operational service in Northern Ireland and Iraq.

After leaving the Regular Army, Ant founded Evocatus Consulting Ltd in 2016. He also co-founded Evocatus Media in 2023 and serves as a Director of ETSA CIC, the European Training and Simulation Association.

In the Army Reserve, Ant commanded B Squadron and then served as Commanding Officer of The Royal Wessex Yeomanry (Jul 2022 to Mar 2025). Since April 2025 he has held the role of SO1 Employer Engagement South West.

## Expertise

Wargaming, exercise design, military training, facilitation, engagement, red teaming, crisis and scenario games, consent building, leadership development, decision support, armoured warfare.

## Publishing

- [*Wavell Room*](https://wavellroom.com/) — writing on diversity and the warrior ethos.
- ["Wargaming: The Challenges of Preconceptions"](https://ludogogy.professorgame.com/article/wargaming-the-challenges-of-preconceptions/), *Ludogogy Magazine*, 5 Nov 2020. Coined **BOPSAT** (Bunch Of People Sat round A Table) and framed wargaming's value as "lifting people's gaze" from daily battles to the horizon.
- [Zero Echo](https://zeroecho.uk/) — Ant's personal journal of working notes on strategy, scenarios, mission command, contingency, pedagogy, vocation and craft, simulation technology, AI and cognition, and reading notes. Companion [Bluesky account](https://bsky.app/profile/zeroecho.uk).

## Related

- [[CRM/organisations/defence companies/Evocatus|Evocatus Consulting Ltd]] — Director and Founder.

---

*This contact has given permission for MilUX to share their details in this template. 2026-05-22. Confirmed.*

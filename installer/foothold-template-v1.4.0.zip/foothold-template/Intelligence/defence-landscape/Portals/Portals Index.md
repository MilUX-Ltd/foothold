---
type: map
status: active
created: 2026-05-20
last_reviewed: 2026-05-20
tags: [index, portals, defence-procurement, sme]
---

# Portals Index

Procurement and opportunity-discovery portals that defence-sector SMEs need to know. Each portal has its own page in this folder. Distinct from the [[Intelligence/defence-landscape/Frameworks/Frameworks Index|frameworks]], which are commercial routes to market; portals are the platforms that those frameworks and direct procurements flow through. Most entries here are free UK government surfaces; private and international aggregators are noted where useful.

## UK government portals

- [[Intelligence/defence-landscape/Portals/Helios SME Portal|Helios SME Portal]]. Essential SME registration. JOSCAR-linked.
- [[Intelligence/defence-landscape/Portals/Contracts Finder|Contracts Finder]]. Central live-opportunity index for UK public-sector contracts.
- [[Intelligence/defence-landscape/Portals/Defence Sourcing Portal|Defence Sourcing Portal]]. MOD-specific supplier portal.
- [[Intelligence/defence-landscape/Portals/MOD Acquisition Pipeline|MOD Acquisition Pipeline]]. Forward-look publication for upcoming MOD procurement activity.
- [[Intelligence/defence-landscape/Portals/Central Digital Platform|Central Digital Platform]]. Procurement Act 2023 platform.
- [[Intelligence/defence-landscape/Portals/Find a Tender Service|Find a Tender Service (FTS)]]. Central publication service for high-value (above-threshold) public procurement notices. Post-Brexit replacement for OJEU / TED; sits inside the Central Digital Platform.

## Community and innovation portals

- [[Intelligence/defence-landscape/Portals/D3IP|D3IP]]. Innovation-as-a-service community portal for Dorset Innovation Park, co-located with the Defence BattleLab.

## Private community and aggregator platforms

- [[Intelligence/defence-landscape/Portals/DefTechLink|DefTechLink]]. Paid platform aggregating defence and dual-use opportunities across ~29 allied countries, with explainer content. One-month free trial; $35/month after.
- [[Intelligence/defence-landscape/Portals/RAINCLOUD DEFENSE|RAINCLOUD DEFENSE]]. Free invitation-only international community platform for the defence-tech sector. 6,600+ members in 100+ countries. Member directory, opportunities board, editorial news, Pavilions.

## Related

- [[Intelligence/defence-landscape/Defence Landscape Index|Defence Landscape Index]]. Parent.
- [[Intelligence/defence-landscape/Frameworks/Frameworks Index|Frameworks Index]]. Commercial frameworks that supplier portals feed into.
